<?php
$mysqli = mysqli_connect("192.168.0.153", "root", "root", "test") or die("Could not connect database");
?>

