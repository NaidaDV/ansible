# Basic-CRUD-php
Beginer to PHP and MYSQL

This Repository Contains Basic CRUD operation in php as Create, Insert, Update, Delete data along with Mysql database


This is Basic Operation and simple code for beginer in php...

You can Download this repository by zip file or Copy or solve your error in code....

It contains :
  1.index.php - For Displaying records of employee
  2.delete.php - For delete records of employee
  3.add.php - For adding records of employee
  4.update.php - For Upadating Record of employee 
  5.login.php - For login in session
  6.logout.php - For destroy the session
  
 Download zip file from it and extract it, import test.sql file in your database and move php scripts into your server folder
 
